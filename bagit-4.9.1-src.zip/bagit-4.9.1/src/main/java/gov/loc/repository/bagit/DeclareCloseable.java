package gov.loc.repository.bagit;

import java.io.Closeable;

public interface DeclareCloseable {
	Closeable declareCloseable();
}
