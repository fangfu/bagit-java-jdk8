package gov.loc.repository.bagit;

import gov.loc.repository.bagit.utilities.namevalue.NameValueWriter;

public interface BagItTxtWriter extends NameValueWriter {

}
