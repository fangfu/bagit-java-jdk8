package gov.loc.repository.bagit;

import gov.loc.repository.bagit.utilities.namevalue.NameValueWriter;

public interface BagInfoTxtWriter extends NameValueWriter {

}
